from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
import numpy as np
import json,os,io,time
BASE=Path(__file__).resolve().parents[1]
results=[]
def ok(name,value):
 assert value,name
 results.append(name);print('PASS',name,flush=True)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=False,args=['--no-sandbox','--use-gl=angle','--use-angle=gl','--ignore-gpu-blocklist','--enable-webgl'],env={**os.environ,'DISPLAY':':91','LIBGL_ALWAYS_SOFTWARE':'1'},timeout=15000)
 page=browser.new_page(viewport={'width':1100,'height':800},device_scale_factor=1,has_touch=True)
 errors=[];requests=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('console',lambda e:errors.append(e.text) if e.type=='error' else None)
 page.on('request',lambda r:requests.append(r.url))
 page.set_content((BASE/'dist/index.html').read_text(),wait_until='load')
 page.wait_for_function('window.__island?.ready',timeout=30000)
 page.evaluate('window.__island.setPaused(true)')
 page.add_style_tag(content='*{transition:none!important;animation:none!important}')
 page.locator('#loader').evaluate('(e)=>e.hidden=true')
 ok('WebGL2 starts without shader or JS errors',not errors and page.evaluate('window.__island.stats().glError')==0)
 ok('48k-class physical water vertices',page.evaluate('window.__island.stats().waterVertices')==47802)
 ok('No remote runtime requests',not requests)
 t=page.evaluate('window.__island.stats().shoreTime');page.wait_for_timeout(150);ok('Pause holds wave time',page.evaluate('window.__island.stats().shoreTime')==t)
 page.locator('#settings').click();ok('Settings panel opens',page.locator('#settings-panel').is_visible())
 page.locator('#shore').fill('0');page.locator('#shore').dispatch_event('input');ok('Shoreline slider can reach zero',page.evaluate('window.__island.stats().settings.shore')==0)
 page.locator('#ripple').fill('165');page.locator('#ripple').dispatch_event('input');ok('Ripple slider independent of shoreline',page.evaluate('window.__island.stats().settings.ripple')==1.65)
 page.locator('#sunset').click();ok('Sunset changes renderer lighting',page.evaluate('window.__island.stats().theme')=='sunset')
 page.locator('.diagnostics summary').click();page.locator('#depth').check();ok('Depth view switches on',page.evaluate('window.__island.stats().depthMode'))
 page.locator('#depth').uncheck();page.locator('#wireframe').check();ok('Mesh wireframe switches on',page.evaluate('window.__island.stats().wireframe'))
 page.locator('#wireframe').uncheck();page.locator('#rotate').check();page.wait_for_timeout(150)
 yaw=page.evaluate('window.__island.stats().camera.yaw');page.wait_for_timeout(300)
 ok('Pause also holds automatic camera rotation',abs(page.evaluate('window.__island.stats().camera.yaw')-yaw)<.00001)
 page.locator('#rotate').uncheck();page.locator('#reset').click();ok('Reset restores all four water controls',page.evaluate('Object.values(window.__island.stats().settings).every(x=>x===1)'))
 page.evaluate('window.__island.setPaused(true)');page.locator('#close-settings').click()
 page.locator('#shore-view').click();ok('Close-up selects shore view',page.evaluate('window.__island.stats().view')=='shore')
 page.evaluate("window.__island.setView('shore',true);document.body.classList.add('capture')")
 def shot(s,r,params):
  page.evaluate('a=>{window.__island.setParams(a.p);window.__island.setTimes(a.s,a.r);window.__island.render()}',{'s':s,'r':r,'p':params})
  return np.array(Image.open(io.BytesIO(page.screenshot())).convert('RGB'),dtype=np.int16)
 def delta(a,b):return float(np.abs(a-b).mean())
 A=shot(0,0,{'shore':1,'ripple':0,'refraction':1,'foam':1});B=shot(2,0,{})
 shoreDelta=delta(A,B);ok('Shoreline-only motion changes rendered image',shoreDelta>.2)
 A=shot(0,0,{'shore':0,'ripple':1});B=shot(0,1.6,{})
 rippleDelta=delta(A,B);ok('Ripple-only motion changes rendered image',rippleDelta>.1)
 A=shot(1,1,{'shore':1,'ripple':1,'refraction':0,'foam':1});B=shot(1,1,{'refraction':1})
 refractionDelta=delta(A,B);ok('Real refraction changes submerged pixels',refractionDelta>.1)
 A=shot(.35,.5,{'foam':0});B=shot(.35,.5,{'foam':2})
 foamDelta=delta(A,B);ok('Foam strength changes rendered shoreline',foamDelta>.05)
 page.evaluate("document.body.classList.remove('capture');window.__island.setParams({shore:1,ripple:1,refraction:1,foam:1});window.__island.setView('overview',true)")
 page.set_viewport_size({'width':390,'height':844});page.evaluate("window.__island.setView('overview',true);window.__island.render()")
 ok('Portrait view fits the entire island',page.evaluate('window.__island.stats().camera.radius')>60)
 ok('No horizontal overflow on phone',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 page.screenshot(path=str(BASE/'previews/mobile.png'))
 pixels=np.array(Image.open(BASE/'previews/mobile.png').convert('RGB'),dtype=np.int16)[290:570,45:360]
 ok('Portrait foliage retains color instead of distance-fog washout',int(np.sum((pixels[:,:,1]>pixels[:,:,0]+10)&(pixels[:,:,1]>pixels[:,:,2]+65)))>500)
 page.locator('#settings').click();bounds=page.locator('#settings-panel').bounding_box();ok('Mobile settings stay inside screen',bounds['x']>=0 and bounds['x']+bounds['width']<=391 and bounds['y']>30)
 page.screenshot(path=str(BASE/'previews/mobile-settings.png'))
 page.locator('#close-settings').click()
 old=page.evaluate('window.__island.stats().camera.yaw');page.mouse.move(195,420);page.mouse.down();page.mouse.move(245,430,steps=4);page.mouse.up();page.wait_for_timeout(700);ok('Drag orbits the island',abs(page.evaluate('window.__island.stats().camera.yaw')-old)>.05)
 # Trusted two-touch input through CDP tests the actual pointer/pinch path.
 cdp=page.context.new_cdp_session(page)
 old=page.evaluate('window.__island.stats().camera.radius')
 cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':150,'y':420,'id':1},{'x':240,'y':420,'id':2}]})
 cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':120,'y':420,'id':1},{'x':270,'y':420,'id':2}]})
 cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});page.wait_for_timeout(800)
 ok('Two-finger pinch changes camera distance',page.evaluate('window.__island.stats().camera.radius')<old-2)
 ok('No accumulated GL, shader, or JS errors',not errors and page.evaluate('window.__island.stats().glError')==0)
 data={'passed':results,'errors':errors,'networkRequests':requests,'pixelMeanAbsoluteDifferences':{'shoreOnly':shoreDelta,'rippleOnly':rippleDelta,'refraction':refractionDelta,'foam':foamDelta},'environment':'Chromium 144, WebGL2, Mesa llvmpipe under Xvfb; built HTML loaded directly with set_content because URL navigation is sandbox-blocked. Not a native iPad/Safari performance test.'}
 (BASE/'previews/verification.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 browser.close()
print(f'{len(results)} browser checks passed',flush=True)
