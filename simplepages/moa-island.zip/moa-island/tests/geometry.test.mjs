import test from 'node:test';import assert from 'node:assert/strict';
import {Geometry,createOcean,createTerrain} from '../src/geometry.js';
test('box has twelve triangles with valid finite normals',()=>{const g=new Geometry();g.box([0,0,0],[1,1,1],0xffffff);assert.equal(g.count,36);assert.ok(g.array.every(Number.isFinite));});
test('ocean is real indexed dense geometry',()=>{const g=createOcean();assert.ok(g.positions.length/3>10000);assert.ok(Math.max(...g.indices.subarray(0,5000))<g.positions.length/3);});
test('terrain has finite geometry at the radial pole and winding points up',()=>{const g=createTerrain();assert.ok(g.array.every(Number.isFinite));assert.ok(g.count>10000);});
