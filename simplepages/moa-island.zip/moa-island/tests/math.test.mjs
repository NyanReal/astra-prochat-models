import test from 'node:test';
import assert from 'node:assert/strict';
// Import the module only if present, to report the missing feature as an assertion.
const m = await import('../src/math.js').catch(() => ({}));
test('terrain is land at the center and underwater offshore', () => {
  assert.equal(typeof m.terrainHeight, 'function', 'terrainHeight must exist');
  assert.ok(m.terrainHeight(0,0) > 1);
  assert.ok(m.terrainHeight(25,0) < -3);
});
test('shoreline signal moves independently of ripple time', () => {
  assert.equal(typeof m.waterHeight, 'function', 'waterHeight must exist');
  const s={shore:1,ripple:0};
  assert.notEqual(m.waterHeight(8,0,0,0,s),m.waterHeight(8,0,2,0,s));
  assert.equal(m.waterHeight(8,0,2,0,s),m.waterHeight(8,0,2,30,s));
});
test('ripple signal keeps moving with shoreline disabled', () => {
  assert.equal(typeof m.waterHeight, 'function', 'waterHeight must exist');
  const s={shore:0,ripple:1};
  assert.notEqual(m.waterHeight(10,2,0,0,s),m.waterHeight(10,2,0,1,s));
  assert.equal(m.waterHeight(10,2,0,1,s),m.waterHeight(10,2,20,1,s));
});
test('zero strengths produce an exactly level surface', () => {
  assert.equal(typeof m.waterHeight, 'function', 'waterHeight must exist');
  for(let i=0;i<20;i++) assert.equal(m.waterHeight(i,3,8,9,{shore:0,ripple:0}),0);
});
test('foam fades with age and vanishes rather than staying a fixed white band', () => {
  assert.equal(typeof m.foamLife, 'function', 'foamLife must exist');
  assert.ok(m.foamLife(.1)>m.foamLife(.7));
  assert.ok(m.foamLife(.7)>m.foamLife(1.4));
  assert.equal(m.foamLife(3),0);
});
test('disabled shoreline has no deposited foam and no NaN', () => {
  assert.equal(typeof m.foamAge, 'function', 'foamAge must exist');
  assert.equal(m.foamAge(8,0,0,2,0),Infinity);
});
test('settings sanitize invalid and out-of-range values', () => {
  assert.equal(typeof m.normalizeSettings, 'function', 'normalizeSettings must exist');
  const s=m.normalizeSettings({shore:-2,ripple:99,refraction:NaN,foam:0});
  assert.equal(s.shore,0); assert.equal(s.ripple,2); assert.equal(s.refraction,1); assert.equal(s.foam,0);
});
test('all sampled heights remain finite at the origin and across the shore', () => {
  assert.equal(typeof m.terrainHeight, 'function', 'terrainHeight must exist');
  for(let x=-12;x<=12;x+=.5) for(let z=-12;z<=12;z+=.5) {
    assert.ok(Number.isFinite(m.terrainHeight(x,z)));
    assert.ok(Number.isFinite(m.waterHeight(x,z,1,3,{shore:1,ripple:1})));
  }
});
test('view-projection inverse round trips a world point',()=>{
 const vp=m.multiply(m.perspective(Math.PI/4,1.6,.1,200),m.lookAt([16,18,22],[0,0,0]));
 const p=[2,.1,7], round=m.transformPoint(m.inverse(vp),m.transformPoint(vp,p));
 round.forEach((v,i)=>assert.ok(Math.abs(v-p[i])<.001));
});
