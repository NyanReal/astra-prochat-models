# 개발 검사 재현

기본 계산/메시 검사는 Node.js만 사용합니다.

```sh
npm test
npm run build
node --check dist/app.check.js
```

브라우저 검사와 미리보기 캡처는 별도 개발 도구인 Python Playwright, Pillow, NumPy, Chromium, Xvfb 및 Mesa를 사용합니다. 사이트 사용자에게 이 도구들이 필요한 것은 아닙니다. 스크립트의 기본 Chromium 실행 경로는 `/usr/bin/chromium`, 테스트 디스플레이는 `:91`입니다. 이 환경에서의 재현 명령은 다음과 같습니다.

```sh
Xvfb :91 -screen 0 1440x1000x24 -nolisten tcp &
python tests/verify_browser.py
DISPLAY=:91 python scripts/capture-previews.py
ffmpeg -y -i previews/waves.gif -vf 'fps=30,format=yuv420p' -c:v libx264 -crf 21 -movflags +faststart previews/waves.mp4
```

테스트는 네트워크 없이 빌드 HTML 원문을 `set_content`로 실행합니다. 공개 호스팅이나 Sites에 대한 배포 검사는 아닙니다. 다른 OS에서 실행할 때는 해당 환경의 브라우저 경로와 그래픽 실행 설정을 사용해야 합니다.
