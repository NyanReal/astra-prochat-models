"""Render screenshots of the actual built website, not illustrative mockups.
Requires Playwright, Pillow and a Chromium with WebGL2. On this Linux host,
DISPLAY=:91 is an Xvfb display and Mesa provides software GL. Timed frames
are deterministic samples, NOT a realtime frame-rate benchmark.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
import os, io, json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'previews'; OUT.mkdir(exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),headless=False,
        args=['--no-sandbox','--use-gl=angle','--use-angle=gl','--ignore-gpu-blocklist','--enable-webgl'],
        env={**os.environ,'DISPLAY':os.getenv('DISPLAY',':91'),'LIBGL_ALWAYS_SOFTWARE':'1'})
    page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_content((ROOT/'dist/index.html').read_text(),wait_until='load')
    page.wait_for_function('window.__island?.ready',timeout=30000)
    page.evaluate('window.__island.setPaused(true)')
    page.add_style_tag(content='*{transition:none!important;animation:none!important}')
    page.locator('#loader').evaluate('(el)=>el.hidden=true')
    def render(view,s=1.4,r=2,theme='day'):
        page.evaluate('a=>{window.__island.setView(a.view,true);window.__island.setTheme(a.theme);window.__island.setTimes(a.s,a.r);window.__island.render()}',{'view':view,'s':s,'r':r,'theme':theme})
    render('overview');page.screenshot(path=str(OUT/'overview.png'))
    render('overview',theme='sunset');page.screenshot(path=str(OUT/'sunset.png'))
    render('shore');page.screenshot(path=str(OUT/'shore.png'))
    page.set_viewport_size({'width':1024,'height':1366});render('overview');page.screenshot(path=str(OUT/'tablet.png'))
    page.set_viewport_size({'width':960,'height':640})
    page.evaluate("document.body.classList.add('capture')")
    render('shore')
    page.evaluate("window.__island.getState().wireframe=true;window.__island.render()")
    page.screenshot(path=str(OUT/'water-wireframe.png'))
    page.evaluate('window.__island.getState().wireframe=false;window.__island.setParams({shore:1,ripple:1,refraction:1,foam:1})')
    images=[]
    for i in range(42):
        t=i*.2
        page.evaluate('t=>{window.__island.setTimes(t,t);window.__island.render()}',t)
        image=Image.open(io.BytesIO(page.screenshot())).convert('RGB')
        images.append(image)
        if i in [3,11,22,31]: image.save(OUT/f'wave-stage-{i:02d}.png')
        if i%10==0: print(f'Captured {i+1}/42 wave frames',flush=True)
    palette=images[0].quantize(colors=192,method=Image.Quantize.MEDIANCUT)
    frames=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in images]
    frames[0].save(OUT/'waves.gif',save_all=True,append_images=frames[1:],duration=200,loop=0,optimize=True,disposal=1)
    assert not errors,errors
    assert page.evaluate('window.__island.stats().glError')==0
    (OUT/'capture.json').write_text(json.dumps({'source':'dist/index.html','frames':42,'simulationStepSeconds':.2,'durationSeconds':8.4,'renderedSnapshotsNotPerformanceBenchmark':True,'errors':errors},indent=2))
    browser.close()
print('Actual site screenshots and wave GIF captured.',flush=True)
