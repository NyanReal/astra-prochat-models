import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const names=['math','geometry','world','shaders','renderer','camera','app'];
const parts=['/* MOA Island — standalone, no network dependencies. */\n(()=>{\n"use strict";\nconst modules={};\n'];
for(const name of names){let src=await readFile(path.join(root,'src',name+'.js'),'utf8');const exports=[...src.matchAll(/export\s+(?:class|function|const|let)\s+([A-Za-z_$][\w$]*)/g)].map(m=>m[1]);
 src=src.replace(/import\s*\{([^}]+)\}\s*from\s*['"]\.\/([\w-]+)\.js['"];?/g,(_,keys,dep)=>`const {${keys}}=modules.${dep};`).replace(/\bexport\s+(?=(?:class|function|const|let)\b)/g,'');
 if(/\bimport\s+(?:\{|\*)/.test(src))throw new Error(`Unbundled import in ${name}`);
 parts.push(`modules.${name}=(()=>{\n${src}\nreturn {${exports.join(',')}};\n})();\n`);
}
parts.push('})();');const js=parts.join('\n');
const css=await readFile(path.join(root,'src/style.css'),'utf8');let html=await readFile(path.join(root,'index.template.html'),'utf8');html=html.replace('/*__CSS__*/',css).replace('/*__APP__*/',js.replace(/<\/script/gi,'<\\/script'));
await mkdir(path.join(root,'dist'),{recursive:true});await writeFile(path.join(root,'dist/index.html'),html);await writeFile(path.join(root,'dist/app.check.js'),js);console.log(`Built dist/index.html (${(Buffer.byteLength(html)/1024).toFixed(1)} KB); zero remote runtime assets.`);
