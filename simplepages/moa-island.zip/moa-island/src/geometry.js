import {color, cross, normalize, vecSub, vecAdd, vecScale, rotationTransform, terrainHeight, radial, coastRadius, smoothstep, seededRandom} from './math.js';
/** Interleaved POSITION, NORMAL, linear RGB, material-kind; immutable world batches. */
export class Geometry {
 constructor(){this.data=[];}
 vertex(p,n,c,kind=1){this.data.push(...p,...n,...c,kind);}
 triangle(a,b,c,col,kind=1,normals=null){const n=normals||normalize(cross(vecSub(b,a),vecSub(c,a)));this.vertex(a,normals?normals[0]:n,col,kind);this.vertex(b,normals?normals[1]:n,col,kind);this.vertex(c,normals?normals[2]:n,col,kind);}
 quad(a,b,c,d,col,kind=1){this.triangle(a,b,c,col,kind);this.triangle(a,c,d,col,kind);}
 box(pos,size,hex,rot=[0,0,0],kind=1){
  const col=Array.isArray(hex)?hex:color(hex);
  const p=(x,y,z)=>vecAdd(rotationTransform([x*size[0]/2,y*size[1]/2,z*size[2]/2],rot),pos);
  for(const face of [[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]],[[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]],[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]],[[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]],[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]]])this.quad(...face.map(v=>p(...v)),col,kind);
 }
 ellipsoid(pos,scale,hex,segments=10,rings=6,rot=[0,0,0],flat=true,kind=1){
  const col=Array.isArray(hex)?hex:color(hex),p=(a,b)=>{const v=[Math.sin(b)*Math.cos(a),Math.cos(b),Math.sin(b)*Math.sin(a)];return vecAdd(rotationTransform(v.map((n,i)=>n*scale[i]),rot),pos);};
  const norm=(a,b)=>normalize(rotationTransform([Math.sin(b)*Math.cos(a)/scale[0],Math.cos(b)/scale[1],Math.sin(b)*Math.sin(a)/scale[2]],rot));
  for(let j=0;j<rings;j++)for(let i=0;i<segments;i++){
   const a=i/segments*Math.PI*2,A=(i+1)/segments*Math.PI*2,b=j/rings*Math.PI,B=(j+1)/rings*Math.PI;
   if(j>0)this.triangle(p(a,b),p(A,b),p(A,B),col,kind,flat?null:[norm(a,b),norm(A,b),norm(A,B)]);
   if(j<rings-1)this.triangle(p(a,b),p(A,B),p(a,B),col,kind,flat?null:[norm(a,b),norm(A,B),norm(a,B)]);
  }
 }
 cylinder(a,b,r1,r2,hex,segments=9,kind=1){
  const col=Array.isArray(hex)?hex:color(hex),n=normalize(vecSub(b,a)),u=normalize(cross(n,Math.abs(n[1])>.9?[1,0,0]:[0,1,0])),v=cross(n,u);
  const pt=(c,r,t)=>vecAdd(c,vecAdd(vecScale(u,Math.cos(t)*r),vecScale(v,Math.sin(t)*r)));
  for(let i=0;i<segments;i++){const t=i*Math.PI*2/segments,T=(i+1)*Math.PI*2/segments;
   this.quad(pt(a,r1,t),pt(a,r1,T),pt(b,r2,T),pt(b,r2,t),col,kind);
   this.triangle(a,pt(a,r1,T),pt(a,r1,t),col,kind);this.triangle(b,pt(b,r2,t),pt(b,r2,T),col,kind);
  }
 }
 torus(pos,r,tube,hex,rotation=[0,0,0],parts=24){
  const p=(a,b)=>vecAdd(rotationTransform([(r+tube*Math.cos(b))*Math.cos(a),tube*Math.sin(b),(r+tube*Math.cos(b))*Math.sin(a)],rotation),pos);
  for(let i=0;i<parts;i++)for(let j=0;j<6;j++){const a=i/parts*Math.PI*2,A=(i+1)/parts*Math.PI*2,b=j/6*Math.PI*2,B=(j+1)/6*Math.PI*2;const c=color(Array.isArray(hex)?hex[Math.floor(i/3)%hex.length]:hex);this.quad(p(a,b),p(A,b),p(A,B),p(a,B),c);}
 }
 get array(){return new Float32Array(this.data);}
 get count(){return this.data.length/10;}
}
export function createTerrain(){
 const g=new Geometry(),rings=142,sectors=240,verts=[],normals=[],colors=[];
 const sand=color(0xF4DCA1),grass=color(0x8FB95E),deepSand=color(0xB8D4A4);
 for(let j=0;j<=rings;j++){const r=48*Math.pow(j/rings,1.48);for(let i=0;i<=sectors;i++){
  const a=i/sectors*Math.PI*2,x=r*Math.cos(a),z=r*Math.sin(a),y=terrainHeight(x,z),h=.035,q=radial(x,z)/coastRadius(x,z);
  verts.push([x,y,z]);normals.push(normalize([terrainHeight(x-h,z)-terrainHeight(x+h,z),2*h,terrainHeight(x,z-h)-terrainHeight(x,z+h)]));
  const patch=.018*Math.sin(x*5+Math.cos(z*3))+.014*Math.sin(z*7+x*2);const edge=.74+.023*Math.sin(x*1.4+z)+.02*Math.cos(z*1.5-x*.5);
  const green=1-smoothstep(edge-.025,edge+.025,q);let c=sand.map((v,k)=>v+(grass[k]-v)*green);
  const under=smoothstep(-.8,-6.5,y)*.20;c=c.map((v,k)=>v+(deepSand[k]-v)*under+patch*.25);colors.push(c);
 }}
 const idx=(j,i)=>j*(sectors+1)+i;
 const tri=(a,b,c)=>{g.vertex(verts[a],normals[a],colors[a],0);g.vertex(verts[b],normals[b],colors[b],0);g.vertex(verts[c],normals[c],colors[c],0);};
 for(let j=0;j<rings;j++)for(let i=0;i<sectors;i++){const a=idx(j,i),b=idx(j+1,i),c=idx(j+1,i+1),d=idx(j,i+1);tri(a,c,b);if(j>0)tri(a,d,c);}
 return g;
}
export function createOcean(){
 const rings=185,sectors=256,positions=[],indices=[];
 for(let j=0;j<=rings;j++){const r=145*Math.pow(j/rings,1.8);for(let i=0;i<=sectors;i++){const a=i/sectors*Math.PI*2;positions.push(Math.cos(a)*r,0,Math.sin(a)*r);}}
 for(let j=0;j<rings;j++)for(let i=0;i<sectors;i++){const a=j*(sectors+1)+i,b=(j+1)*(sectors+1)+i;indices.push(a,b+1,b,a,a+1,b+1);}
 return {positions:new Float32Array(positions),indices:new Uint32Array(indices)};
}
