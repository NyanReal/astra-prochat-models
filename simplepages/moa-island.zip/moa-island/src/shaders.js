/** GLSL ES 3.00. Keep constants in commonHeight aligned with src/math.js. */
export const commonHeight = `
const float PI=3.14159265359;
const float TAU=6.28318530718;
const float OMEGA=TAU/8.4;
uniform float uShoreTime,uRippleTime,uShore,uRipple,uFoam;
float radial(vec2 p){return length(p/vec2(1.08,.9));}
float coastRadius(vec2 p){float a=atan(p.y/.9,p.x/1.08);return 7.5+.40*sin(3.0*a+.3)+.28*cos(5.0*a-1.0)+.18*sin(7.0*a);}
float terrainHeight(vec2 p){float q=radial(p)/coastRadius(p);float h=mix(1.48+.10*sin(p.x*.55)*cos(p.y*.4),(1.0-q)*3.1,smoothstep(.5,.78,q));h-=pow(max(0.0,q-1.24),1.4)*2.3;return max(-8.5,h);}
float shorePhase(vec2 p){return uShoreTime*OMEGA+.27*sin(atan(p.y,p.x)*3.0)+.08*cos(p.x*.4);}
float shoreAmplitude(vec2 p){float b=(radial(p)-8.0)/6.0;return .28*uShore*exp(-b*b);}
float shoreHeight(vec2 p){return shoreAmplitude(p)*sin(shorePhase(p));}
float waterHeight(vec2 p){
 float h=terrainHeight(p),near=.28+.72*smoothstep(0.0,2.4,max(0.0,-h));
 float ripple=uRipple*near*(.085*sin(p.x*.92+p.y*.53+uRippleTime*1.27)+.043*sin(-p.x*1.48+p.y*1.10+uRippleTime*1.81)+.019*sin(p.x*2.76+p.y*1.77-uRippleTime*2.37));
 return shoreHeight(p)+ripple;
}
float hash21(vec2 p){p=fract(p*vec2(123.34,345.45));p+=dot(p,p+34.345);return fract(p.x*p.y);}
float noise2(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash21(i),hash21(i+vec2(1,0)),f.x),mix(hash21(i+vec2(0,1)),hash21(i+vec2(1,1)),f.x),f.y);}
float foamAge(vec2 p,float h){float a=shoreAmplitude(p);if(a<.00001||abs(h)>a)return 100.0;float crossing=PI-asin(clamp(h/a,-1.0,1.0));return mod(shorePhase(p)-crossing+TAU*2.0,TAU)/OMEGA;}
float foamLife(float age){return exp(-1.35*max(0.0,age))*(1.0-smoothstep(1.5,2.25,age));}
`;
export const sceneVertex=`#version 300 es
precision highp float;
layout(location=0)in vec3 aPosition;
layout(location=1)in vec3 aNormal;
layout(location=2)in vec3 aColor;
layout(location=3)in float aKind;
uniform mat4 uViewProjection,uModel,uLightViewProjection;
out vec3 vWorld,vNormal,vColor;
out vec4 vShadow;
out float vKind;
void main(){vec4 p=uModel*vec4(aPosition,1);vWorld=p.xyz;vNormal=mat3(uModel)*aNormal;vColor=aColor;vKind=aKind;vShadow=uLightViewProjection*p;gl_Position=uViewProjection*p;}
`;
export const sceneFragment=`#version 300 es
precision highp float;
in vec3 vWorld,vNormal,vColor;in vec4 vShadow;in float vKind;
uniform sampler2D uShadow;
uniform vec3 uSunDirection,uSunColor,uSky,uEye;
uniform float uShadowEnabled;
out vec4 fragColor;
${commonHeight}
float shadow(){vec3 p=vShadow.xyz/vShadow.w*.5+.5;if(p.x<0.0||p.x>1.0||p.y<0.0||p.y>1.0||p.z>1.0)return 1.0;float d=0.0,bias=max(.0009,.0025*(1.0-dot(normalize(vNormal),uSunDirection)));
 for(int x=0;x<2;x++)for(int y=0;y<2;y++){vec2 o=(vec2(float(x),float(y))-.5)/1024.0;d+=p.z-bias<=texture(uShadow,p.xy+o).r?1.0:.45;}return d*.25;}
void main(){
 vec3 base=vColor;vec3 n=normalize(vNormal);if(!gl_FrontFacing)n=-n;
 if(vKind<.5){
  vec2 p=vWorld.xz;float h=vWorld.y,q=radial(p)/coastRadius(p),isSand=smoothstep(.71,.80,q);
  float fine=noise2(p*43.0)-.5;
  float stripes=sin(p.x*10.0+2.2*sin(p.y*2.8))*.006;
  base*=1.0+isSand*(fine*.095+stripes);
  float water=waterHeight(p),age=foamAge(p,h);
  float wet=(1.0-smoothstep(.01,.11,h-water))*.70;
  wet=max(wet,exp(-age*.30)*.65);
  base*=1.0-.18*wet*isSand;
  // Caustic illumination is applied to the real seabed before refraction.
  float caustic=pow(max(0.0,1.0-abs(sin(p.x*2.5+sin(p.y*2.8+uRippleTime*.31))*sin(p.y*2.7+sin(p.x*2.1-uRippleTime*.27)))),13.0);
  base+=vec3(.075,.105,.085)*caustic*smoothstep(.05,.55,water-h)*exp(-max(0.0,water-h)*.20)*min(uRipple,1.3);
  // Analytical history: foam that was deposited at the last down-crossing.
  float breakup=noise2(p*9.5)+.25*noise2(p*21.0);
  float residue=foamLife(age)*smoothstep(.32+age*.27,.62+age*.23,breakup)*smoothstep(.005,.035,h-water);
  residue*=isSand*uFoam;
  base=mix(base,vec3(.88,.94,.87),clamp(residue*.82,0.0,.9));
 }
 float diff=max(dot(n,uSunDirection),0.0),shade=mix(1.0,shadow(),uShadowEnabled);
 vec3 light=vec3(.49,.58,.58)+uSunColor*(.74*diff*shade);
 if(vKind>1.5)light+=vec3(.07,.065,.015);
 vec3 lit=base*light;
 // World-anchored haze: responsive camera fitting must not bleach the island.
 float fog=smoothstep(22.0,85.0,length(vWorld.xz));
 fragColor=vec4(mix(lit,uSky,fog),1);
}
`;
export const depthVertex=`#version 300 es
precision highp float;layout(location=0)in vec3 aPosition;uniform mat4 uModel,uLightViewProjection;void main(){gl_Position=uLightViewProjection*uModel*vec4(aPosition,1);}`;
export const depthFragment=`#version 300 es
precision highp float;void main(){}`;
export const quadVertex=`#version 300 es
precision highp float;out vec2 vUv;void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vUv=p;gl_Position=vec4(p*2.0-1.0,0,1);}`;
export const copyFragment=`#version 300 es
precision highp float;in vec2 vUv;uniform sampler2D uSceneColor,uSceneDepth;out vec4 fragColor;void main(){vec3 c=texture(uSceneColor,vUv).rgb;fragColor=vec4(pow(max(c,vec3(0)),vec3(1.0/2.2)),1);gl_FragDepth=texture(uSceneDepth,vUv).r;}`;
export const skyFragment=`#version 300 es
precision highp float;in vec2 vUv;uniform vec3 uSky;out vec4 fragColor;void main(){fragColor=vec4(uSky*(.96+.04*vUv.y),1);}`;
export const waterVertex=`#version 300 es
precision highp float;layout(location=0)in vec3 aPosition;
uniform mat4 uViewProjection;
out vec3 vWorld,vNormal;
${commonHeight}
void main(){vec3 p=aPosition;p.y=waterHeight(p.xz);const float e=.06;
 vNormal=normalize(vec3(waterHeight(p.xz-vec2(e,0))-waterHeight(p.xz+vec2(e,0)),2.0*e,waterHeight(p.xz-vec2(0,e))-waterHeight(p.xz+vec2(0,e))));
 vWorld=p;gl_Position=uViewProjection*vec4(p,1);
}
`;
export const waterFragment=`#version 300 es
precision highp float;
in vec3 vWorld,vNormal;
uniform sampler2D uSceneColor,uSceneDepth;
uniform vec2 uResolution;
uniform mat4 uInverseViewProjection,uView;
uniform vec3 uEye,uSunDirection,uSunColor,uSky;
uniform float uRefraction,uDepthMode,uWireframe;
out vec4 fragColor;
${commonHeight}
vec3 reconstruct(vec2 uv,float depth){vec4 p=uInverseViewProjection*vec4(uv*2.0-1.0,depth*2.0-1.0,1);return p.xyz/p.w;}
void main(){
 vec2 uv=gl_FragCoord.xy/uResolution;float sceneDepth=texture(uSceneDepth,uv).r;
 vec3 ground=reconstruct(uv,sceneDepth);float d=max(0.0,vWorld.y-ground.y);
 if(sceneDepth>.99999)d=20.0;
 vec3 n=normalize(vNormal);n=normalize(n+vec3(sin(vWorld.x*7.0+vWorld.z*4.0+uRippleTime)*.014,0,cos(vWorld.z*6.0-vWorld.x*3.0-uRippleTime*1.2)*.012)*uRipple);
 vec3 normalView=mat3(uView)*n;
 vec2 distortion=normalView.xy*uRefraction*.036*smoothstep(0.0,.7,d);
 vec2 refractedUv=clamp(uv+distortion,vec2(.001),vec2(.999));
 vec3 refractedGround=reconstruct(refractedUv,texture(uSceneDepth,refractedUv).r);
 // Reject above-water foreground; never drag the cabin across the water.
 if(refractedGround.y>vWorld.y-.012)refractedUv=uv;
 vec3 bottom=texture(uSceneColor,refractedUv).rgb;
 float actualDepth=max(0.0,vWorld.y-terrainHeight(vWorld.xz));
 vec3 shallow=vec3(.09,.62,.57),deep=vec3(.025,.27,.34);
 vec3 waterColor=mix(shallow,deep,1.0-exp(-d*.24));
 float absorption=1.0-exp(-d*.62);
 vec3 col=mix(bottom,waterColor,absorption);
 vec3 viewDir=normalize(uEye-vWorld);float fresnel=pow(1.0-max(dot(n,viewDir),0.0),4.0);
 vec3 reflected=reflect(-viewDir,n);
 vec3 reflection=mix(uSky*.63,uSky,clamp(reflected.y*.5+.5,0.0,1.0));
 col=mix(col,reflection,.055+fresnel*.36);
 col*=.95+.09*max(dot(n,uSunDirection),0.0);
 vec3 halfDir=normalize(viewDir+uSunDirection);float spec=pow(max(dot(n,halfDir),0.0),180.0);
 col+=uSunColor*spec*.47;
 // Broken, fading foam attached to the actual animated depth boundary.
 float grain=noise2(vWorld.xz*6.0+vec2(uShoreTime*.07,-uShoreTime*.025));
 float fine=noise2(vWorld.xz*20.0);
 float edge=(1.0-smoothstep(.03,.145,actualDepth+(grain-.5)*.10))*smoothstep(.002,.022,actualDepth);
 float lace=.12+.88*smoothstep(.37,.78,grain+.21*fine);
 float incoming=.12+.88*smoothstep(-.12,.72,cos(shorePhase(vWorld.xz)));
 float foam=edge*lace*incoming;
 // A second fragmented wash line travels toward shore and disappears each cycle.
 float phase=fract((uShoreTime+.6)/8.4);float bandDepth=.76*(1.0-phase);
 float trailing=exp(-pow((actualDepth-bandDepth)*32.0,2.0))*pow(max(0.0,sin(phase*PI)),3.0)*smoothstep(.45,.80,grain+.12*fine)*.22;
 foam=(foam+trailing)*uFoam*min(1.0,uShore+.25*uRipple);
 col=mix(col,vec3(.92,.965,.92),clamp(foam,0.0,.94));
 if(uDepthMode>.5){col=mix(vec3(.7,.93,.61),vec3(.02,.08,.38),clamp(d/6.0,0.0,1.0));float iso=abs(fract(d*2.0)-.5);col*=.8+.2*smoothstep(.0,.045,iso);}
 float fog=smoothstep(22.0,85.0,length(vWorld.xz));col=mix(col,uSky,fog);
 fragColor=vec4(pow(max(col,vec3(0)),vec3(1.0/2.2)),1);
}
`;

export const wireVertex=waterVertex.replace("gl_Position=uViewProjection*vec4(p,1);","gl_Position=uViewProjection*vec4(p,1);gl_Position.z-=.000012*gl_Position.w;");
export const wireFragment=`#version 300 es
precision highp float;out vec4 fragColor;void main(){fragColor=vec4(.12,.33,.28,1);}`;
