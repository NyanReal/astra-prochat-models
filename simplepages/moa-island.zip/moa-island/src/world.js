import {Geometry} from './geometry.js';
import {terrainHeight,color,seededRandom,vecAdd,vecSub,vecScale,normalize,cross,radial,coastRadius} from './math.js';

const C={trunk:0x987044,wood:0xBC8D59,lightWood:0xDFBA82,darkWood:0x795440,cream:0xFFF0C7,roof:0xCF7763,roofLight:0xE58D74,teal:0x4E9290,leaf:0x6EAB61};
export function createWorld(){
 const g=new Geometry(),random=seededRandom(1987),animated=[];
 function palm(x,z,s=1,lean=.55){
  const ground=terrainHeight(x,z),h=3.5*s;
  let prev=[x,ground-.03,z];
  for(let i=1;i<=7;i++){const t=i/7,p=[x+lean*t*t,ground+h*t,z+.15*Math.sin(t*2)];g.cylinder(prev,p,(.20-.065*(i-1)/7)*s,(.20-.065*t)*s,i%2?C.trunk:0xAC8356,8);prev=p;}
  const crown=prev;
  for(let k=0;k<8;k++){
   const a=k*Math.PI/4+.18,dir=[Math.cos(a),0,Math.sin(a)],side=[-dir[2],0,dir[0]],length=(1.55+random()*.35)*s;
   const p=(t,w,mid=false)=>[crown[0]+dir[0]*length*t+side[0]*w,crown[1]+Math.sin(t*Math.PI*.9)*.54*s-.7*s*t*t+(mid?.10*s:0),crown[2]+dir[2]*length*t+side[2]*w];
   for(let j=0;j<7;j++){const t=j/7,T=(j+1)/7,w=Math.sin(t*Math.PI)*.30*s,W=Math.sin(T*Math.PI)*.30*s,col=color([0x72AD61,0x80B969,0x5C9C5A,0x91BF6B][k%4]);g.quad(p(t,-w),p(T,-W),p(T,0,true),p(t,0,true),col,2);g.quad(p(t,0,true),p(T,0,true),p(T,W),p(t,w),col,2);}
  }
  for(let i=0;i<3;i++){const a=i*2.2;g.ellipsoid([crown[0]+Math.cos(a)*.19,crown[1]-.12,crown[2]+Math.sin(a)*.19],[.17*s,.21*s,.17*s],0x866045,7,5);}
  g.ellipsoid([crown[0],crown[1]+.20,crown[2]],[.21*s,.48*s,.22*s],0x8FBC6E,7,5);
 }
 function tree(x,z,s=1){const y=terrainHeight(x,z);g.cylinder([x,y,z],[x,y+1.65*s,z],.18*s,.13*s,C.trunk,7);
  g.cylinder([x,y+.9*s,z],[x+.42*s,y+1.9*s,z],.095*s,.05*s,C.trunk,6);
  for(const [ox,oy,oz,rx,ry,rz,hex] of [[-.4,1.8,0,.94,.82,.87,0x83B66B],[.44,2.05,.1,.83,.85,.82,0xA0C678],[.06,2.54,-.13,.92,.85,.9,0x8CBF73]])g.ellipsoid([x+ox*s,y+oy*s,z+oz*s],[rx*s,ry*s,rz*s],hex,9,6,[0,random(),.1],true,2);
 }
 function rock(x,z,s=.5,raise=0,hex=0xA8A998){const y=terrainHeight(x,z);g.ellipsoid([x,y+s*.32+raise,z],[s,s*.67,s*.77],hex,7,4,[.1,random()*3,.08]);}
 function flower(x,z,hex,s=1){const y=terrainHeight(x,z);g.cylinder([x,y,z],[x,y+.26*s,z],.022*s,.012*s,0x669257,5);const c=[x,y+.30*s,z];for(let i=0;i<5;i++){const a=i*Math.PI*2/5;g.ellipsoid([c[0]+Math.cos(a)*.075*s,c[1],c[2]+Math.sin(a)*.075*s],[.064*s,.035*s,.064*s],hex,5,3);}g.ellipsoid([c[0],c[1]+.025*s,c[2]],[.035*s,.035*s,.035*s],0xE9B650,5,3);}
 function grassTuft(x,z,s=1){const y=terrainHeight(x,z);for(let i=0;i<3;i++){const a=i*2.1,b=[x+Math.cos(a)*.16*s,y,z+Math.sin(a)*.16*s];g.triangle([x-.06*s,y,z],[x+.06*s,y,z],[b[0],y+.33*s,b[2]],color(i===1?0x799F59:0xA7C778),2);}}
 function hut(x,z){const y=terrainHeight(x,z),w=2.35,h=1.65,d=2.05;
  g.box([x,y+.14,z],[w+.22,.28,d+.20],C.darkWood);
  g.box([x,y+.28+h/2,z],[w,h,d],C.cream);
  const top=y+.28+h;
  // Gable ends and two pitched roof slabs, ridge along z.
  for(const sign of [-1,1]){const Z=z+sign*d/2;const a=[x-w/2,top,Z],b=[x+w/2,top,Z],c=[x,top+.86,Z];g.triangle(...(sign>0?[a,b,c]:[b,a,c]),color(C.cream));}
  const slope=Math.atan2(.88,w/2+.22),roofLen=Math.hypot(.88,w/2+.22);
  for(const sign of [-1,1]){
   g.box([x+sign*(w/4+.11),top+.44,z],[roofLen+.10,.16,d+.58],sign<0?C.roof:C.roofLight,[0,0,-sign*slope]);
   for(let i=0;i<9;i++)g.box([x+sign*(w/4+.11),top+.53,z-d/2-.17+i*(d+.34)/8],[roofLen+.12,.035,.024],0xC97362,[0,0,-sign*slope]);
  }
  g.box([x,top+.93,z],[.14,.12,d+.67],0xBB6A59);
  g.box([x+.60,top+.83,z-.48],[.30,.86,.34],0xEACBA2);g.box([x+.60,top+1.28,z-.48],[.40,.13,.44],0xC5A88D);
  const front=z+d/2+.025;
  g.box([x-.42,y+.85,front],[.62,1.22,.065],C.darkWood);g.box([x-.42,y+.84,front+.037],[.50,1.12,.055],C.teal);
  for(let i=0;i<3;i++)g.box([x-.55+i*.14,y+.83,front+.072],[.015,1.01,.012],0x42817E);
  g.ellipsoid([x-.25,y+.85,front+.11],[.043,.043,.045],0xE8BD6B,7,4);
  g.box([x+.53,y+1.18,front],[.68,.66,.08],C.darkWood);g.box([x+.53,y+1.18,front+.045],[.57,.54,.035],0x86C8C4);
  g.box([x+.53,y+1.18,front+.07],[.035,.56,.025],C.cream);g.box([x+.53,y+1.18,front+.075],[.59,.035,.025],C.cream);
  g.box([x+.53,y+.85,front+.10],[.83,.12,.23],C.wood);
  for(let i=0;i<4;i++)g.ellipsoid([x+.29+i*.16,y+.98,front+.14],[.12,.13,.1],[0xA7BB6E,0xF0C776,0xDB8C87,0x8EAF62][i],6,4);
  // Porch, steps and awning.
  for(let i=0;i<12;i++)g.box([x-w/2-.10+i*.23,y+.22,z+d/2+.45],[.205,.13,.9],i%3?C.lightWood:0xD4A76F);
  g.box([x-.4,y+.08,z+d/2+1.03],[.98,.16,.31],C.wood);
  for(const ox of [-1.21,1.21])g.cylinder([x+ox,y+.26,z+d/2+.79],[x+ox,y+1.72,z+d/2+.79],.045,.04,C.lightWood,7);
  for(let i=0;i<10;i++)g.box([x-1.17+i*.26,y+1.75,z+d/2+.42],[.261,.045,.95],i%2?0xF3D8A9:0xDB967D,[.16,0,0]);
  // Round side porthole.
  g.cylinder([x+w/2+.015,y+1.24,z-.18],[x+w/2+.065,y+1.24,z-.18],.28,.28,C.darkWood,16);
  g.cylinder([x+w/2+.07,y+1.24,z-.18],[x+w/2+.08,y+1.24,z-.18],.22,.22,0x98D8D1,16);
  // Hand-built path of broad stepping stones.
  for(let i=0;i<5;i++){const px=x-.4+Math.sin(i*.8)*.12,pz=z+d/2+1.28+i*.47;g.ellipsoid([px,terrainHeight(px,pz)+.045,pz],[.27,.065,.20],0xD7C8A3,7,3,[0,random(),0]);}
 }
 function umbrella(x,z,s=1,hex=0xECA76F){const y=terrainHeight(x,z),h=1.95*s;g.cylinder([x,y,z],[x,y+h,z],.045*s,.035*s,C.lightWood,8);
  const segments=12,center=[x,y+h+.16*s,z];
  for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,A=(i+1)/segments*Math.PI*2,mid=(a+A)/2;
   const p=t=>[x+Math.cos(t)*s,y+h-.35*s,z+Math.sin(t)*s];const col=color(i%2?0xFFF0CD:hex);
   g.triangle(center,p(A),p(a),col);g.triangle(p(a),p(A),[x+Math.cos(mid)*1.02*s,y+h-.48*s,z+Math.sin(mid)*1.02*s],col);
   g.cylinder(center,p(a),.012,.008,C.lightWood,4);
  }
  g.ellipsoid([x,y+h+.20*s,z],[.075*s,.09*s,.075*s],hex,7,4);
 }
 function chair(x,z,rot=0,hex=0xE7A978){const y=terrainHeight(x,z);const conv=(p)=>{const c=Math.cos(rot),s=Math.sin(rot);return[x+p[0]*c+p[2]*s,y+p[1],z-p[0]*s+p[2]*c];};
  for(const sx of [-.31,.31]){g.cylinder(conv([sx,0,-.28]),conv([sx,.65,.28]),.037,.037,C.wood,6);g.cylinder(conv([sx,0,.45]),conv([sx,.43,-.20]),.037,.037,C.wood,6);}
  g.box(conv([0,.4,.12]),[.59,.055,.61],hex,[0,rot,0]);g.box(conv([0,.73,-.22]),[.59,.69,.045],hex,[-.23,rot,0]);
  for(const sx of [-.18,0,.18]){g.box(conv([sx,.433,.12]),[.075,.006,.60],0xFFF1C9,[0,rot,0]);g.box(conv([sx,.73,-.192]),[.075,.66,.008],0xFFF1C9,[-.23,rot,0]);}
 }
 function starfish(x,z,s=.18){const y=terrainHeight(x,z)+.027;for(let i=0;i<5;i++){const a=i*Math.PI*2/5;g.triangle([x-.06*Math.sin(a),y,z+.06*Math.cos(a)],[x+.06*Math.sin(a),y,z-.06*Math.cos(a)],[x+Math.cos(a)*s,y+.015,z+Math.sin(a)*s],color(0xDF9278));}}

 hut(-1.65,-1.72);
 palm(3.0,-2.1,1.1,.45);palm(4.45,-.20,.91,.58);palm(-5.0,1.45,1.10,-.40);palm(-3.90,3.35,.82,-.24);
 tree(-3.1,-4.0,1.12);tree(-.80,-4.6,.95);tree(1.6,-4.1,.89);tree(-4.80,-2.25,.85);
 umbrella(1.35,3.75,.89,0xDC9576);chair(.75,4.10,-.10,0xE3AA7D);chair(1.85,4.32,.10,0xDEA487);
 g.cylinder([1.35,terrainHeight(1.35,4.58),4.58],[1.35,terrainHeight(1.35,4.58)+.40,4.58],.06,.06,C.wood,7);
 g.cylinder([1.35,terrainHeight(1.35,4.58)+.40,4.58],[1.35,terrainHeight(1.35,4.58)+.47,4.58],.29,.29,C.cream,12);
 g.cylinder([1.39,terrainHeight(1.35,4.58)+.48,4.58],[1.39,terrainHeight(1.35,4.58)+.60,4.58],.055,.063,0x87B9A4,7);
 // Picnic blanket and a soft, low beach bag.
 const by=terrainHeight(-1.7,4.5)+.03;g.box([-1.7,by,4.5],[1.28,.035,.90],0x8FC4C2,[0,.17,0]);
 for(let i=0;i<5;i++)g.box([-2.23+i*.24,by+.021,4.5],[.09,.006,.83],0xDFF0D8,[0,.17,0]);
 g.ellipsoid([-2.05,by+.19,4.3],[.22,.21,.17],0xD4AA70,8,5);g.torus([-2.05,by+.37,4.3],.105,.025,C.wood,[Math.PI/2,0,0],12);
 // A slightly crooked beach sign.
 const sy=terrainHeight(-.10,2.65);g.cylinder([-.1,sy,2.65],[-.14,sy+.86,2.65],.045,.04,C.wood,7);
 g.box([-.14,sy+.78,2.65],[.73,.28,.09],0xD7AB73,[0,.05,-.07]);
 for(let i=0;i<3;i++)g.box([-.36+i*.18,sy+.79+Math.sin(i*2)*.025,2.71],[.12,.025,.012],0x5E9290,[0,0,i%2?.15:-.15]);
 // String of bunting between trees, draped rather than straight.
 const B0=[-4.1,2.15,.1],B1=[1.75,2.0,.45];
 for(let i=0;i<16;i++){const t=i/16,T=(i+1)/16,pt=q=>[B0[0]+(B1[0]-B0[0])*q,B0[1]+(B1[1]-B0[1])*q-.32*Math.sin(q*Math.PI),B0[2]+(B1[2]-B0[2])*q];g.cylinder(pt(t),pt(T),.012,.012,C.darkWood,4);if(i%2===1){const a=pt(t),b=pt(T+.045),mid=vecScale(vecAdd(a,b),.5);mid[1]-=.28;g.triangle(a,b,mid,color([0xE5A784,0xF4D084,0xA6C5A6,0x8FBDBD][Math.floor(i/2)%4]));}}
 // Dock, reaching from the sand into deeper water.
 for(let i=0;i<20;i++)g.box([5.35+i*.24,.62,1.95],[.213,.14,1.18],i%4===1?0xCA9B65:C.lightWood);
 for(const x of [5.5,7.2,9.75])for(const z of [1.43,2.47]){g.cylinder([x,-1.9,z],[x,.96,z],.077,.067,C.wood,8);g.cylinder([x,.90,z],[x,.99,z],.09,.09,C.lightWood,8);}
 g.box([7.5,.44,1.48],[4.3,.14,.14],C.darkWood);g.box([7.5,.44,2.42],[4.3,.14,.14],C.darkWood);
 g.torus([9.45,.72,2.17],.27,.075,[0xFFF1D6,0xDD8B74],[0,0,.05],24);
 // Shore rocks and submerged reference objects for visible refraction.
 for(const r of [[-6,-2,.68],[-6.7,-1,.45],[5.2,-3.8,.73],[5.8,-3.2,.45],[6.4,-4.2,.42],[-4.9,-5,.48],[-4.0,-5.8,.40]])rock(...r);
 for(let i=0;i<40;i++){const a=random()*Math.PI*2,r=7.3+random()*5.3,x=Math.cos(a)*r*1.08,z=Math.sin(a)*r*.9,s=.12+random()*.38;rock(x,z,s,0,[0xC0BEA3,0xADBAA9,0x98AC9F,0xD6C6A7][i%4]);}
 for(const [x,z,s] of [[2.8,6.4,.36],[3.55,6.9,.26],[4.1,7.0,.45],[2.3,7.1,.2],[3.0,7.6,.32],[4.4,7.7,.22]])rock(x,z,s,0,0xA3B7A7);
 for(let i=0;i<70;i++){const x=(random()-.5)*10,z=(random()-.5)*9,q=radial(x,z)/coastRadius(x,z);if(q>.68||((x+1.65)**2+(z+1.72)**2<4.5))continue;if(i%3===0)flower(x,z,[0xFFF0BF,0xEDB3A0,0xF4D57E][i%3],.75+random()*.25);else grassTuft(x,z,.65+random()*.6);}
 for(const [x,z] of [[3.3,5.4],[4.7,4.4],[-.3,5.7],[-3.8,4.95]])starfish(x,z,.15+random()*.05);
 for(let i=0;i<15;i++){const a=.2+random()*2.6,r=6.0+random()*.95,x=Math.cos(a)*r,z=Math.sin(a)*r*.9;if(terrainHeight(x,z)<.02)continue;g.ellipsoid([x,terrainHeight(x,z)+.04,z],[.09,.045,.075],0xF9E9C8,6,4,[0,random(),0]);}
 // Rowboat: separate local batch, bobbed/tilted using the same water-height model.
 const boat=new Geometry(),N=24,ring=(a,r,y)=>[Math.cos(a)*1.12*r,y,Math.sin(a)*.45*r];
 for(let i=0;i<N;i++){const a=i/N*Math.PI*2,A=(i+1)/N*Math.PI*2;boat.quad(ring(a,.60,-.10),ring(A,.60,-.10),ring(A,1,.30),ring(a,1,.30),color(0xD38B6E));boat.quad(ring(a,1,.30),ring(A,1,.30),ring(A,.86,.25),ring(a,.86,.25),color(0xF0C48F));boat.quad(ring(a,.86,.25),ring(A,.86,.25),ring(A,.54,.02),ring(a,.54,.02),color(0xAA7954));boat.triangle([0,.02,0],ring(a,.55,.02),ring(A,.55,.02),color(0xB58E63));}
 boat.box([-.34,.22,0],[.22,.08,.67],C.lightWood);boat.box([.36,.22,0],[.22,.08,.67],C.lightWood);
 boat.cylinder([-.80,.38,-.42],[.75,.44,.64],.025,.024,C.wood,7);boat.ellipsoid([.86,.44,.71],[.24,.027,.115],C.lightWood,8,4,[0,-.55,0]);
 animated.push({name:'boat',geometry:boat,position:[10.8,0,3.30],rotation:[0,-.42,0]});
 // A pair of very simple gulls on the beach.
 for(const [x,z,r] of [[-.9,5.7,.1],[-.25,5.3,-.5]]){const y=terrainHeight(x,z);g.ellipsoid([x,y+.16,z],[.15,.13,.23],0xFFF8DD,8,5,[0,r,0]);g.ellipsoid([x,y+.31,z+.12],[.1,.10,.11],0xFFF9E6,7,5);g.cylinder([x,y+.30,z+.19],[x,y+.29,z+.30],.035,.001,0xD7A653,5);g.ellipsoid([x+.068,y+.32,z+.177],[.013,.015,.014],0x4A5A51,5,3);}
 return {geometry:g,animated};
}
