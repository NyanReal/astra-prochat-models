import {normalizeSettings,waterHeight,foamAge,foamLife} from './math.js';
import {createTerrain,createOcean} from './geometry.js';
import {createWorld} from './world.js';
import {IslandRenderer} from './renderer.js';
import {IslandCamera} from './camera.js';

const $=id=>document.getElementById(id);
const state={shoreTime:1.15,rippleTime:.4,settings:normalizeSettings(),running:true,depthMode:false,wireframe:false,quality:'auto',dirty:true};
let renderer,camera,ready=false,toastTimer,audio=null,audioGain=null,soundOn=false,stopped=false;
function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2300);}
function fail(error){console.error(error);$('loader').hidden=true;$('error-message').textContent=error.message||String(error);$('error-panel').hidden=false;window.__islandError=error.message||String(error);}
function setPanel(open){$('settings-panel').hidden=!open;$('settings').setAttribute('aria-expanded',String(open));document.body.classList.toggle('settings-open',open);}
function setParams(values){state.dirty=true;state.settings=normalizeSettings({...state.settings,...values});for(const key of ['shore','ripple','refraction','foam']){const value=Math.round(state.settings[key]*100);$(key).value=value;$(key+'-value').value=value+'%';$(key).style.setProperty('--fill',value/2+'%');}}
function setPaused(paused){state.dirty=true;state.running=!paused;$('pause').setAttribute('aria-pressed',String(paused));$('pause').setAttribute('aria-label',paused?'애니메이션 다시 재생':'애니메이션 멈추기');$('pause').querySelector('span').textContent=paused?'다시 재생':'멈추기';}
function setView(name,immediate=false){state.dirty=true;camera?.setPreset(name,immediate);const shore=name==='shore';document.body.classList.toggle('shore-mode',shore);$('overview').classList.toggle('active',!shore);$('overview').setAttribute('aria-pressed',String(!shore));$('shore-view').classList.toggle('active',shore);$('shore-view').setAttribute('aria-pressed',String(shore));$('scene-label').innerHTML=shore?'02 &nbsp; / &nbsp; 발끝에 닿는 파도':'01 &nbsp; / &nbsp; 섬의 느린 오후';}
function setTheme(theme){state.dirty=true;renderer?.setTheme(theme);for(const t of ['day','sunset']){$(t).classList.toggle('selected',theme===t);$(t).setAttribute('aria-pressed',String(theme===t));}document.querySelector('.live-indicator').innerHTML='<i></i>'+(theme==='sunset'?'노을이 머무는 시간':'느리게 흐르는 오후');}
function resize(){if(!renderer)return;renderer.resize(innerWidth,innerHeight,state.quality);camera?.refit();state.dirty=true;}
async function toggleSound(){try{
 if(!audio){const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw new Error('이 브라우저에서는 소리를 재생할 수 없어요.');audio=new Audio();const buffer=audio.createBuffer(1,audio.sampleRate*8,audio.sampleRate),data=buffer.getChannelData(0);let pink=0;for(let i=0;i<data.length;i++){pink=.98*pink+.02*(Math.random()*2-1);data[i]=pink*5;}
  const source=audio.createBufferSource();source.buffer=buffer;source.loop=true;const filter=audio.createBiquadFilter();filter.type='lowpass';filter.frequency.value=720;audioGain=audio.createGain();audioGain.gain.value=0;source.connect(filter);filter.connect(audioGain);audioGain.connect(audio.destination);source.start();
 }
 await audio.resume();soundOn=!soundOn;$('sound').setAttribute('aria-pressed',String(soundOn));$('sound').setAttribute('aria-label',soundOn?'파도 소리 끄기':'파도 소리 켜기');audioGain.gain.setTargetAtTime(soundOn?.15:0,audio.currentTime,.25);toast(soundOn?'작은 파도 소리를 켰어요.':'파도 소리를 껐어요.');
 }catch(error){toast(error.message||'소리를 재생하지 못했어요.');}}
function bindUI(){
 $('settings').addEventListener('click',()=>setPanel($('settings-panel').hidden));$('close-settings').addEventListener('click',()=>setPanel(false));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')setPanel(false);if(e.code==='Space'&&(e.target===document.body||e.target===$('island'))){e.preventDefault();setPaused(state.running);}});
 for(const key of ['shore','ripple','refraction','foam'])$(key).addEventListener('input',e=>setParams({[key]:Number(e.target.value)/100}));
 $('pause').addEventListener('click',()=>setPaused(state.running));$('overview').addEventListener('click',()=>setView('overview'));$('shore-view').addEventListener('click',()=>setView('shore'));
 $('home').addEventListener('click',e=>{e.preventDefault();setView('overview');});
 $('day').addEventListener('click',()=>setTheme('day'));$('sunset').addEventListener('click',()=>setTheme('sunset'));
 $('depth').addEventListener('change',e=>{state.depthMode=e.target.checked;state.dirty=true;});$('wireframe').addEventListener('change',e=>{state.wireframe=e.target.checked;state.dirty=true;});$('rotate').addEventListener('change',e=>camera.autoRotate=e.target.checked);
 $('quality').addEventListener('change',e=>{state.quality=e.target.value;resize();});
 $('reset').addEventListener('click',()=>{setParams({shore:1,ripple:1,refraction:1,foam:1});state.depthMode=state.wireframe=false;$('depth').checked=$('wireframe').checked=$('rotate').checked=false;camera.autoRotate=false;setTheme('day');setPaused(false);toast('처음의 바다로 돌아왔어요.');});$('sound').addEventListener('click',toggleSound);
 window.addEventListener('resize',resize);document.addEventListener('visibilitychange',()=>{if(audioGain&&audio)audioGain.gain.setTargetAtTime(soundOn&&!document.hidden?.15:0,audio.currentTime,.15);});
}
function boot(){try{
 const terrain=createTerrain(),world=createWorld(),ocean=createOcean();renderer=new IslandRenderer($('island'),terrain,world,ocean);camera=new IslandCamera($('island'));camera.setPreset('overview',true);camera.update();resize();bindUI();setParams({});
 renderer.onContextLoss=()=>{stopped=true;fail(new Error('그래픽 연결이 끊겼어요. 다시 열면 섬으로 돌아갈 수 있어요.'));};renderer.onContextRestore=()=>location.reload();
 window.__island={ready:false,stats:()=>({...renderer.stats(),running:state.running,shoreTime:state.shoreTime,rippleTime:state.rippleTime,settings:{...state.settings},depthMode:state.depthMode,wireframe:state.wireframe,view:camera.preset,camera:{radius:camera.radius,yaw:camera.yaw,polar:camera.polar}}),setParams,setView,setPaused,setTheme,
  setTimes:(s,r)=>{state.shoreTime=s;state.rippleTime=r;state.dirty=true;},render:()=>{camera.update(.016,state.running);renderer.render(camera,state);state.dirty=false;},sample:(x,z)=>({height:waterHeight(x,z,state.shoreTime,state.rippleTime,state.settings),foamAge:foamAge(x,z,0,state.shoreTime,state.settings.shore)}),getSceneData:()=>({terrain:terrain.array,world:world.geometry.array,ocean}),getState:()=>state};
 if(matchMedia('(prefers-reduced-motion: reduce)').matches)setPaused(true);
 let previous=performance.now();function loop(now){if(stopped)return;const dt=Math.min(.06,Math.max(0,(now-previous)/1000));previous=now;
  if(!document.hidden){if(state.running){state.shoreTime+=dt;state.rippleTime+=dt;}const changed=camera.update(dt,state.running);if(state.running||changed||state.dirty||!ready){renderer.render(camera,state);state.dirty=false;}
   if(audioGain&&audio&&soundOn)audioGain.gain.setTargetAtTime(.11+.04*Math.sin(state.shoreTime*Math.PI*2/8.4),audio.currentTime,.14);
   if(!ready){ready=true;window.__island.ready=true;$('loader').classList.add('done');setTimeout(()=>$('loader').hidden=true,650);}
  }requestAnimationFrame(loop);
 }requestAnimationFrame(loop);
 }catch(error){fail(error);}}
// Leave the first paint free so loading and accessibility UI appear immediately.
setTimeout(boot,35);
