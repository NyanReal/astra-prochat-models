import {identity,multiply,lookAt,orthographic,inverse,normalize,color,modelMatrix,waterHeight} from './math.js';
import {sceneVertex,sceneFragment,depthVertex,depthFragment,quadVertex,copyFragment,skyFragment,waterVertex,waterFragment,wireVertex,wireFragment} from './shaders.js';

class Program {
 constructor(gl,vs,fs,label){this.gl=gl;this.label=label;this.uniforms={};
  const compile=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){const log=gl.getShaderInfoLog(s);gl.deleteShader(s);throw new Error(`${label}: ${log}`);}return s;};
  const v=compile(gl.VERTEX_SHADER,vs),f=compile(gl.FRAGMENT_SHADER,fs);this.p=gl.createProgram();gl.attachShader(this.p,v);gl.attachShader(this.p,f);gl.linkProgram(this.p);gl.deleteShader(v);gl.deleteShader(f);
  if(!gl.getProgramParameter(this.p,gl.LINK_STATUS))throw new Error(`${label}: ${gl.getProgramInfoLog(this.p)}`);
  for(let i=0;i<gl.getProgramParameter(this.p,gl.ACTIVE_UNIFORMS);i++){const u=gl.getActiveUniform(this.p,i);this.uniforms[u.name]={location:gl.getUniformLocation(this.p,u.name),type:u.type};}
 }
 use(){this.gl.useProgram(this.p);}
 set(name,value){const gl=this.gl,u=this.uniforms[name];if(!u)return;const l=u.location;
  switch(u.type){case gl.FLOAT:gl.uniform1f(l,value);break;case gl.INT:case gl.BOOL:case gl.SAMPLER_2D:gl.uniform1i(l,value);break;case gl.FLOAT_VEC2:gl.uniform2fv(l,value);break;case gl.FLOAT_VEC3:gl.uniform3fv(l,value);break;case gl.FLOAT_VEC4:gl.uniform4fv(l,value);break;case gl.FLOAT_MAT4:gl.uniformMatrix4fv(l,false,value);break;default:throw new Error(`Unsupported uniform type: ${name}`);}
 }
 apply(values){for(const [name,value]of Object.entries(values))this.set(name,value);}
}
export class IslandRenderer {
 constructor(canvas,terrain,world,ocean){
  this.canvas=canvas;this.gl=canvas.getContext('webgl2',{alpha:false,antialias:true,depth:true,powerPreference:'high-performance',preserveDrawingBuffer:false});
  if(!this.gl)throw new Error('이 브라우저에서 WebGL 2를 사용할 수 없어요. 하드웨어 가속이 켜진 Safari 또는 Chrome에서 열어 주세요.');
  const gl=this.gl;this.programs={scene:new Program(gl,sceneVertex,sceneFragment,'island'),depth:new Program(gl,depthVertex,depthFragment,'shadow'),copy:new Program(gl,quadVertex,copyFragment,'composite'),sky:new Program(gl,quadVertex,skyFragment,'sky'),water:new Program(gl,waterVertex,waterFragment,'water'),wire:new Program(gl,wireVertex,wireFragment,'wireframe')};
  this.terrain=this.upload(terrain.array);this.props=this.upload(world.geometry.array);
  this.animated=world.animated.map(a=>({...a,mesh:this.upload(a.geometry.array)}));this.ocean=this.uploadOcean(ocean);this.emptyVao=gl.createVertexArray();
  this.width=0;this.height=0;this.frame=0;this.shadowDirty=true;this.theme='day';this.setTheme('day');this.shadow=this.createTarget(1024,1024,false);
  this.waterVertices=ocean.positions.length/3;this.triangles=terrain.count/3+world.geometry.count/3+ocean.indices.length/3;
  this.lost=false;canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;this.onContextLoss?.();});
  canvas.addEventListener('webglcontextrestored',()=>this.onContextRestore?.());
 }
 upload(data){const gl=this.gl,vao=gl.createVertexArray(),buffer=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);for(const [i,size,offset]of [[0,3,0],[1,3,12],[2,3,24],[3,1,36]]){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,size,gl.FLOAT,false,40,offset);}gl.bindVertexArray(null);return {vao,buffer,count:data.length/10};}
 uploadOcean(data){const gl=this.gl,vao=gl.createVertexArray(),buffer=gl.createBuffer(),index=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,data.positions,gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,12,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,data.indices,gl.STATIC_DRAW);const lines=new Uint32Array(data.indices.length*2);for(let i=0,j=0;i<data.indices.length;i+=3){const a=data.indices[i],b=data.indices[i+1],c=data.indices[i+2];lines[j++]=a;lines[j++]=b;lines[j++]=b;lines[j++]=c;lines[j++]=c;lines[j++]=a;}const lineIndex=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,lineIndex);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,lines,gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index);gl.bindVertexArray(null);return {vao,buffer,index,lineIndex,lineCount:lines.length,count:data.indices.length};}
 createTarget(w,h,withColor=true){const gl=this.gl,fbo=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);let texture=null;
  if(withColor){texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA8,w,h,0,gl.RGBA,gl.UNSIGNED_BYTE,null);this.textureParams(gl.LINEAR);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,texture,0);}
  else{gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);}
  const depth=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,depth);gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,w,h,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);this.textureParams(gl.NEAREST);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,depth,0);
  if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw new Error('렌더링 버퍼를 만들지 못했어요. 화질을 낮춰 다시 열어 주세요.');gl.bindFramebuffer(gl.FRAMEBUFFER,null);return {fbo,color:texture,depth,w,h};
 }
 textureParams(filter){const gl=this.gl;gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,filter);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,filter);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);}
 deleteTarget(t){if(!t)return;const gl=this.gl;gl.deleteFramebuffer(t.fbo);if(t.color)gl.deleteTexture(t.color);gl.deleteTexture(t.depth);}
 resize(w,h,quality='auto'){const dpr=quality==='low'?Math.min(devicePixelRatio||1,1):quality==='high'?Math.min(devicePixelRatio||1,2):Math.min(devicePixelRatio||1,1.5);const W=Math.max(1,Math.round(w*dpr)),H=Math.max(1,Math.round(h*dpr));if(W===this.width&&H===this.height)return;this.width=W;this.height=H;this.canvas.width=W;this.canvas.height=H;this.deleteTarget(this.target);this.target=this.createTarget(W,H,true);}
 bindTexture(tex,unit){const gl=this.gl;gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(gl.TEXTURE_2D,tex);}
 setTheme(theme){this.theme=theme;this.sun=normalize(theme==='sunset'?[-12,9,13]:[-10,19,12]);this.sunColor=theme==='sunset'?[1.10,.74,.47]:[1.04,.97,.82];this.sky=color(theme==='sunset'?0xE9D3B8:0xB4DCDB);
  const eye=this.sun.map(v=>v*35);this.lightVP=multiply(orthographic(-15,15,-15,15,1,80),lookAt(eye,[0,0,0]));this.shadowDirty=true;
 }
 meshDraw(mesh,program,model=identity()){const gl=this.gl;program.set('uModel',model);gl.bindVertexArray(mesh.vao);gl.drawArrays(gl.TRIANGLES,0,mesh.count);}
 quad(){this.gl.bindVertexArray(this.emptyVao);this.gl.drawArrays(this.gl.TRIANGLES,0,3);}
 render(camera,state){if(this.lost||!this.target)return;const gl=this.gl,pr=this.programs;const common={uViewProjection:camera.vp,uView:camera.view,uInverseViewProjection:inverse(camera.vp),uLightViewProjection:this.lightVP,uEye:camera.eye,uSunDirection:this.sun,uSunColor:this.sunColor,uSky:this.sky,uShoreTime:state.shoreTime,uRippleTime:state.rippleTime,uShore:state.settings.shore,uRipple:state.settings.ripple,uFoam:state.settings.foam,uRefraction:state.settings.refraction,uDepthMode:state.depthMode?1:0,uWireframe:state.wireframe?1:0,uShadowEnabled:1,uResolution:[this.width,this.height]};
  gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.depthFunc(gl.LEQUAL);
  if(this.shadowDirty){gl.bindFramebuffer(gl.FRAMEBUFFER,this.shadow.fbo);gl.viewport(0,0,1024,1024);gl.clear(gl.DEPTH_BUFFER_BIT);pr.depth.use();pr.depth.apply(common);this.meshDraw(this.terrain,pr.depth);this.meshDraw(this.props,pr.depth);this.shadowDirty=false;}
  gl.bindFramebuffer(gl.FRAMEBUFFER,this.target.fbo);gl.viewport(0,0,this.width,this.height);gl.clearColor(...this.sky,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  gl.disable(gl.DEPTH_TEST);pr.sky.use();pr.sky.apply(common);this.quad();gl.enable(gl.DEPTH_TEST);
  pr.scene.use();pr.scene.apply(common);this.bindTexture(this.shadow.depth,2);pr.scene.set('uShadow',2);this.meshDraw(this.terrain,pr.scene);this.meshDraw(this.props,pr.scene);
  for(const a of this.animated){const [x,,z]=a.position,h=waterHeight(x,z,state.shoreTime,state.rippleTime,state.settings);const rotation=[.035*Math.sin(state.rippleTime*1.3)*state.settings.ripple,a.rotation[1],.055*Math.sin(state.rippleTime*1.2+.2)*state.settings.ripple];this.meshDraw(a.mesh,pr.scene,modelMatrix([x,h+.06,z],rotation));}
  // Copy opaque color AND depth; land therefore correctly occludes water.
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,this.width,this.height);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.depthFunc(gl.ALWAYS);pr.copy.use();this.bindTexture(this.target.color,0);this.bindTexture(this.target.depth,1);pr.copy.set('uSceneColor',0);pr.copy.set('uSceneDepth',1);this.quad();
  gl.depthFunc(gl.LEQUAL);pr.water.use();pr.water.apply(common);pr.water.set('uSceneColor',0);pr.water.set('uSceneDepth',1);gl.bindVertexArray(this.ocean.vao);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.ocean.index);gl.drawElements(gl.TRIANGLES,this.ocean.count,gl.UNSIGNED_INT,0);if(state.wireframe){pr.wire.use();pr.wire.apply(common);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.ocean.lineIndex);gl.drawElements(gl.LINES,this.ocean.lineCount,gl.UNSIGNED_INT,0);}gl.bindVertexArray(null);this.frame++;
 }
 stats(){return {frame:this.frame,waterVertices:this.waterVertices,triangles:this.triangles,width:this.width,height:this.height,webglVersion:this.gl.getParameter(this.gl.VERSION),theme:this.theme,glError:this.gl.getError()};}
}
