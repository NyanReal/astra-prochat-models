/** Shared deterministic terrain/water model. Length units are scene meters. */
export const TAU = Math.PI * 2;
export const SHORE_OMEGA = TAU / 8.4;
export const clamp = (x,a,b) => Math.min(b,Math.max(a,x));
export function smoothstep(a,b,x){const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);}
export function radial(x,z){return Math.hypot(x/1.08,z/.9);}
export function coastRadius(x,z){const a=Math.atan2(z/.9,x/1.08);return 7.5+.40*Math.sin(3*a+.3)+.28*Math.cos(5*a-1)+.18*Math.sin(7*a);}
export function terrainHeight(x,z){
 const q=radial(x,z)/coastRadius(x,z);
 const plateau=1.48+.10*Math.sin(x*.55)*Math.cos(z*.4);
 const beach=(1-q)*3.1;
 let h=plateau+(beach-plateau)*smoothstep(.5,.78,q);
 h-=Math.pow(Math.max(0,q-1.24),1.4)*2.3;
 return Math.max(-8.5,h);
}
export function shorePhase(x,z,t){return t*SHORE_OMEGA+.27*Math.sin(Math.atan2(z,x)*3)+.08*Math.cos(x*.4);}
export function shoreAmplitude(x,z,strength=1){return .28*strength*Math.exp(-Math.pow((radial(x,z)-8)/6,2));}
export function shoreHeight(x,z,t,strength=1){return shoreAmplitude(x,z,strength)*Math.sin(shorePhase(x,z,t));}
export function rippleHeight(x,z,t,strength=1){
 const h=terrainHeight(x,z), near= .28+.72*smoothstep(0,2.4,Math.max(0,-h));
 return strength*near*(.085*Math.sin(x*.92+z*.53+t*1.27)+.043*Math.sin(-x*1.48+z*1.10+t*1.81)+.019*Math.sin(x*2.76+z*1.77-t*2.37));
}
export function waterHeight(x,z,shoreTime,rippleTime,settings={shore:1,ripple:1}){
 return (shoreHeight(x,z,shoreTime,settings.shore??1)+rippleHeight(x,z,rippleTime,settings.ripple??1)) || 0;
}
export function foamAge(x,z,height,shoreTime,strength=1){
 const a=shoreAmplitude(x,z,strength);
 if(a<.00001||Math.abs(height)>a) return Infinity;
 const downCross=Math.PI-Math.asin(clamp(height/a,-1,1));
 return ((shorePhase(x,z,shoreTime)-downCross)%TAU+TAU)%TAU/SHORE_OMEGA;
}
export function foamLife(age){return Math.exp(-1.35*Math.max(0,age))*(1-smoothstep(1.5,2.25,age));}
export function normalizeSettings(input={}){
 const s={};for(const k of ['shore','ripple','refraction','foam'])s[k]=Number.isFinite(input[k])?clamp(input[k],0,2):1;
 return s;
}
export function seededRandom(seed=2381){return ()=>{seed=(Math.imul(1664525,seed)+1013904223)|0;return (seed>>>0)/4294967296;};}
export function vecAdd(a,b){return a.map((v,i)=>v+b[i]);}
export function vecSub(a,b){return a.map((v,i)=>v-b[i]);}
export function vecScale(a,s){return a.map(v=>v*s);}
export function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
export function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
export function normalize(a){const l=Math.hypot(...a)||1;return a.map(v=>v/l);}
export function identity(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);}
export function multiply(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];return o;}
export function perspective(fov,aspect,near,far){const f=1/Math.tan(fov/2),n=1/(near-far);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*n,-1,0,0,2*far*near*n,0]);}
export function orthographic(l,r,b,t,n,f){return new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1]);}
export function lookAt(eye,target,up=[0,1,0]){const z=normalize(vecSub(eye,target)),x=normalize(cross(up,z)),y=cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]);}
export function inverse(m){
 const a=Array.from({length:4},(_,r)=>[m[r],m[4+r],m[8+r],m[12+r],...Array.from({length:4},(_,c)=>+(r===c))]);
 for(let c=0;c<4;c++){let p=c;for(let r=c+1;r<4;r++)if(Math.abs(a[r][c])>Math.abs(a[p][c]))p=r;
  if(Math.abs(a[p][c])<1e-12)throw new Error('Singular matrix');[a[c],a[p]]=[a[p],a[c]];const d=a[c][c];for(let k=0;k<8;k++)a[c][k]/=d;
  for(let r=0;r<4;r++)if(r!==c){const f=a[r][c];for(let k=0;k<8;k++)a[r][k]-=f*a[c][k];}
 }
 const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)out[c*4+r]=a[r][c+4];return out;
}
export function transformPoint(m,p){const w=m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15];return [0,1,2].map(i=>(m[i]*p[0]+m[4+i]*p[1]+m[8+i]*p[2]+m[12+i])/w);}
export function rotationTransform(p,r=[0,0,0]){
 let [x,y,z]=p,c=Math.cos(r[0]),s=Math.sin(r[0]);[y,z]=[y*c-z*s,y*s+z*c];c=Math.cos(r[1]);s=Math.sin(r[1]);[x,z]=[x*c+z*s,-x*s+z*c];c=Math.cos(r[2]);s=Math.sin(r[2]);[x,y]=[x*c-y*s,x*s+y*c];return [x,y,z];
}
export function modelMatrix(position=[0,0,0],rotation=[0,0,0]){const o=identity();for(let i=0;i<3;i++){const v=[0,0,0];v[i]=1;const r=rotationTransform(v,rotation);for(let j=0;j<3;j++)o[i*4+j]=r[j];}o[12]=position[0];o[13]=position[1];o[14]=position[2];return o;}
export function color(hex){return [((hex>>16)&255)/255,((hex>>8)&255)/255,(hex&255)/255].map(v=>Math.pow(v,2.2));}
